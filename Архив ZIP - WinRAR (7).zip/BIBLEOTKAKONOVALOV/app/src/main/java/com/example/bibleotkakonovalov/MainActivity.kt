package com.example.bibleotkakonovalov

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText

@SuppressLint("StaticFieldLeak")
private lateinit var loginn: EditText;
private lateinit var password: EditText;

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }


    fun nextEcran(view: View?) {
        val intent = Intent(this, SecondActivity::class.java)
        startActivity(intent)
    }

    fun login(view: View?){
        fun onClickButton(
            inflater: LayoutInflater,
            conteiner: ViewGroup?
        ) {
            val view: View = inflater.inflate(R.layout.activity_main, conteiner, false)
            loginn = view.findViewById(R.id.loginText) as EditText
            password = view.findViewById(R.id.pass) as EditText
        }

    }

    class SecondActivity : AppCompatActivity() {
        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.bibleotek_activity)
        }

    }
}
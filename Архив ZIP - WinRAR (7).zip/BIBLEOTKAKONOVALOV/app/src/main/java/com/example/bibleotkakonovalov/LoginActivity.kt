package com.example.bibleotkakonovalov

import android.widget.EditText

class LoginActivity {
    private lateinit var login: EditText
    private lateinit var password: EditText









}